

<?php

require_once "controllers/template.controller.php";

$template = new  TemplateController();
$template -> template();