<?php
class TemplateController{

    public static function template(){

         include "views/template.php";

    }

}