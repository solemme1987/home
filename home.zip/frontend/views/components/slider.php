<div class="slider-area">
        <div class="pogoSlider pogoSlider--dirCenterHorizontal" style="padding-bottom: 40%;">
            <div class="pogoSlider-slide" data-transition="expandReveal" data-duration="1000" style="background-image: url(&quot;views/assets/images/cafetal.png&quot;); opacity: 1; z-index: 1;">
                <div class="container-slider one">                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="slider-text-content">
                                <h3 class="pogoSlider-slide-element pogoSlider-animation-slideDownIn" data-in="slideDown" data-out="slideUp" data-duration="500" data-delay="500"  style="opacity: 1; animation-duration: 500ms; z-index: 1;">El buen servicio es nuestra pasión</h3>
                                <h2 class="pogoSlider-slide-element pogoSlider-animation-slide-leftIn" data-in="slide-left" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 1; animation-duration: 500ms; z-index: 1;">Increibles casas campestres</h2>
                                <p class="pogoSlider-slide-element pogoSlider-animation-slideDownIn" data-in="slideDown" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 1; animation-duration: 500ms; z-index: 1;"> en Armenia</p>
                                <a href="#" class="button pogoSlider-slide-element pogoSlider-animation-slideDownIn" data-in="slideDown" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 1; animation-duration: 500ms; z-index: 1;">Ofertas Especiales</a>
                            </div><!-- /.text-content -->
                        </div><!-- /.col-md-12 -->
                    </div><!-- /.row -->
                </div><!-- /.container-slider -->
            </div>
            <div class="pogoSlider-slide" data-transition="expandReveal" data-duration="1000" style="background-image: url('views/assets/images/cafetal.png');">
                <div class="container-slider one">                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="slider-text-content">
                                <h3 class="pogoSlider-slide-element" data-in="slideDown" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 0;">Good Service is our passion</h3>
                                <h2 class="pogoSlider-slide-element" data-in="slide-left" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 0;">Awesome apartment Villa</h2>
                                <p class="pogoSlider-slide-element" data-in="slideDown" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 0;">No matter what the weather, no matter what the situation we are in, if we have the right perspective in life, life will always be beautiful!</p>
                                <a href="#" class="button pogoSlider-slide-element" data-in="slideDown" data-out="slideUp" data-duration="500" data-delay="500" style="opacity: 0;">Special Offer</a>
                            </div><!-- /.text-content -->
                        </div><!-- /.col-md-12 -->
                    </div><!-- /.row -->
                </div><!-- /.container-slider -->
            </div>
        <button class="pogoSlider-dir-btn pogoSlider-dir-btn--prev"></button><button class="pogoSlider-dir-btn pogoSlider-dir-btn--next"></button></div><!-- .pogoSlider -->
    </div>