<div class="col-10 bg-primary mt-5 position-absolute top-0 end-0">
    <h1>PARTIDOS</h1>
    <a href="home">home</a>
</div>