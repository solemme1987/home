<?php
   // s
?>
<div class="modal fade" id="dataHome" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
         <img src="view/assets/img/logo.png" alt="imagen aqui" class="img-fluid mr-2" width="35px">
         <h5 class="modal-title " id="exampleModalLabel"> NOMBRES CASA</h5>
        <button type="button" class="btn-close" id="closeModal" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">


      </div>

      <div class="modal-footer">
         <button type="submit" class="btn btn-primary">Agregar</button>

      </div>

    </div>
  </div>
</div>