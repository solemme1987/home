<!-- https://gumroad.com/l/YRjmEv -->

<header class="col-10 px-4 py-2 mb-5 shadow-sm bg-ligth  position-absolute top-0 end-0"> 
    <div class="row d-flex align-items-center">
        <div class="col">
            <i class="fas fa-bars"></i>
        </div>
        <div class="col d-flex justify-content-end align-items-center">
            <i class="fas fa-bell  ms-3"></i>
            <i class="fas fa-cog ms-3"></i>
            <div class="img-profile ms-3">
                <img class="" src="view/assets/img/profile.png" alt="profile">
            </div>
            <perfil class="ms-3 profile-name">Ricardo cortes</perfil>
        </div>
    </div>
</header>
