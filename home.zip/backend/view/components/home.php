<div class="col-10 bg-primary mt-5 position-absolute top-0 end-0 px-4 d-dlex justify-content">
    <div class="row d-flex justify-content-between mt-5 pb-5">

        <div class="col-8 card-box bg-dark">

          <div class="row">

              <div class="col-3">
                 <div class="card-box border">
                   <p>card1</p>
                 </div>
              </div>

              <div class="col-3 bg-danger">
                   <p>card1</p>
              </div>

              <div class="col-3 bg-warning">
                   <p>card1</p>
              </div>

          </div>

        </div>

        <div class="col-4 bg-success ">
             <p>Side </p>
        </div>
    </div>
</div>