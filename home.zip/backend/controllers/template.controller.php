<?php

class TemplateController{

    public static function template(){
         include "view/template.php";
    }

}